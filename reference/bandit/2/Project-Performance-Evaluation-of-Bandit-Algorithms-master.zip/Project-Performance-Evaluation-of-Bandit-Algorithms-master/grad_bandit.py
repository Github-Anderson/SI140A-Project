import numpy as np

alpha = np.array([0.9, 0.9, 0.9])
beta = np.array([1.1, 1.1, 1.1])
upperbound = np.array([0.8, 0.8, 0.8])
lowerbound = np.array([0.3, 0.3, 0.3])
