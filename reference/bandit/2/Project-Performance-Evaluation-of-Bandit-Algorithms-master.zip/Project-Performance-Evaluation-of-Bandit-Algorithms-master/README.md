# Project-Performance-Evaluation-of-Bandit-Algorithms

ShanghaiTech 2023 Fall Project:Project: Performance Evaluation of Bandit Algorithms

**If you think the project is inspirational or interesting, please give it a star.**

This is a report on the study of multi-bandit using the knowledge of Probability and Reinforcement Learning. In this report, we implement several classical bandit algorithms: $\epsilon-greedy$, $UCB$, $Thompson \ Sampling$, and our own designed Bayesian Bandit algorithms to evaluate their performance via numerical comparison, and finally gain inspiring intuition.
