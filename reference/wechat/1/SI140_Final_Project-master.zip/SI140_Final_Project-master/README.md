# SI140_Final_Project
Final Project 微信抢红包背后的算法原理 for SI140 Probability and Statistics, Fall 17, ShanghaiTech @1/18/2018
'Data' file includes the real trial data and stimulation data used in this project.   

'Stimulation Code' file includes the stimulation code (in Python) based on my model.   

'Slides' file includes the slides and .tex source code that generates the slides.   

'Report' file includes the report and .tex source code that generates the report.   

